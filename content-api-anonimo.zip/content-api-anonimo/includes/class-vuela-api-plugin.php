<?php

class Vuela_API_Plugin {
    /**
     * Constructor.
     */
    public function __construct() {
        // Incluir el archivo de funciones adicionales.
        require_once plugin_dir_path(__FILE__) . 'functions.php';

        // Acciones y filtros iniciales.
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('wp_logout', [$this, 'clear_plugin_session']);


       
    }

    /**
     * Ejecuta el plugin.
     */
    public function run() {
        // Aquí puedes añadir más métodos si es necesario.
    }

    /**
     * Añade una página al menú de administración.
     */

     public function add_admin_menu() {
        if (!$this->is_user_authenticated()) {
            // Si no está autenticado, agregar un menú temporal con el formulario de login
            add_menu_page(
                __('Contents - Login', 'vuela-api-plugin'),
                __('Contents', 'vuela-api-plugin'),
                'manage_options',
                'content-api-login',  // Slug del menú de login
                [$this, 'render_login_page'], // Mostrar el formulario de login
                'dashicons-lock',
                80
            );
            return; // Salir sin agregar el menú principal
        }

        add_menu_page(
            __('Vuela API', 'vuela-api-plugin'),
            __('Contents', 'vuela-api-plugin'),
            'manage_options',
            'vuela-api-panel',  // Slug del menú principal
            [$this, 'render_vuela_panel_page'], // Función para mostrar el panel
            'dashicons-edit',
            80
        );

        // Submenú para el Calendario de Publicaciones
  /*  add_submenu_page(
        'vuela-api-panel', // Hace que aparezca dentro del menú principal
        __('Calendario de Publicaciones', 'vuela-api-plugin'),
        __('Calendario', 'vuela-api-plugin'),
        'manage_options',
        'vuela-calendar',
        [$this, 'render_vuela_calendar_page']
    );*/
    }
   
    /**
     * Encola los recursos CSS y JS para la página de administración.
     */
    public function enqueue_admin_assets($hook) {
        // Asegúrate de que estás en la página correcta para cargar el JS
        //print_r('Current hook: ' . $hook);
        $allowed_hooks = [
            'toplevel_page_vuela-api',
            'vuela_page_vuela-api-keys',
            'toplevel_page_vuela-api-articles',
            'vuela_page_vuela-api-my-content',
            'toplevel_page_vuela-api-panel',
            'toplevel_page_content-api-login',
            'contenidos_page_vuela-calendar'
        ];
    
        if (!in_array($hook, $allowed_hooks)) {
            return;
        }
    
        wp_enqueue_style('content-api-admin-css', plugin_dir_url(__FILE__) . '../assets/css/admin.css', [], time());//subir 1.0.2
        wp_enqueue_script('content-api-admin-js', plugin_dir_url(__FILE__) . '../assets/js/admin.js', ['jquery'], time(), true);
    
        // ** Cargar FullCalendar solo en la página del calendario **
        /*if ($_GET['section']=='vuela-calendar') {
          
            wp_enqueue_script('fullcalendar-js', 'https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/6.1.15/index.global.min.js', [], null, true);
            wp_enqueue_script('vuela-calendar-js', plugin_dir_url(__FILE__) . '../assets/js/calendar.js', ['jquery', 'fullcalendar-js'], time(), true);
            $locale = get_locale(); 
            $locale = substr($locale, 0, 2); 

            // ** Asegurar que la variable `vuela_ajax` esté disponible antes de ejecutar calendar.js **
            wp_localize_script('vuela-calendar-js', 'vuela_ajax', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'locale'   => $locale,
                'nonce'    => wp_create_nonce('vuela_calendar_nonce'),
            ]);
        
        }*/
        // Localiza las variables para el script
        wp_localize_script('content-api-admin-js', 'VuelaAPI', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('vuela_api_nonce'),
            'error_message' => __('There was an error processing your request.', 'vuela-api-plugin'),
            'processing_message' => __('Generating article, please wait...', 'vuela-api-plugin'),
            'provide_title_or_keyword' => __('Please provide either a title or a keyword.', 'vuela-api-plugin'),
            'processing_button_text' => __('Processing...', 'vuela-api-plugin'),
            'generate_button_text' => __('Generate Article', 'vuela-api-plugin'),
            'view_request_status' => __('You can check the status of your request here.', 'vuela-api-plugin'),
            'selected_contents' => __('To generate the article, you must check at least one box.', 'vuela-api-plugin'),
            'default_button_text_select' => __('Bulk import', 'vuela-api-plugin'),
            'default_button_text_import' => __('Import', 'vuela-api-plugin'),
            'check_request_here' => __('Check it out here.', 'vuela-api-plugin'),
            'button_text_draft' => __('Draft', 'vuela-api-plugin'),
            'button_text_publish' => __('Publish', 'vuela-api-plugin'),
            'select_date_time' => __('Please select a date and time to schedule.', 'vuela-api-plugin'),
            'select_date_time_bulk' => __('Please select a valid date, time, frequency, and number of articles to schedule.', 'vuela-api-plugin'),
        ]);
    }

    /**
     * Renderiza la página de administración.
     */
    public function render_admin_page() {
        include plugin_dir_path(__FILE__) . '../templates/admin-page.php';
    }

    public function render_articles_page() {
              
        // Incluir la plantilla de la página.
        include plugin_dir_path(__FILE__) . '../templates/article-generation-page.php'; 
    }

    public function render_my_content() {
         // Incluir la plantilla de la página.
        include plugin_dir_path(__FILE__) . '../templates/article-my-content.php'; 
    } 
        
    public function render_vuela_panel_page() {
        // Incluimos el archivo que contendrá el diseño del panel
        include plugin_dir_path(__FILE__) . '../templates/menu-layout.php';
    }

    /*public function render_vuela_calendar_page() {
        // Incluimos el archivo que contendrá el diseño del panel
        include plugin_dir_path(__FILE__) . '../templates/calendar-page.php';
    }*/
    
    
    /**
 * Verificar si el usuario está autenticado
 */
private function is_user_authenticated() {
    return isset($_COOKIE['9d6f434c8cd6e78702f172fefdc82d6a43724871']) && $_COOKIE['9d6f434c8cd6e78702f172fefdc82d6a43724871'] === 'true';
}

/**
 * Mostrar el formulario de login
 */
public function render_login_page() {

    $this->save_plugin_user_and_password();
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vuela_login'])) {
        $username = sanitize_text_field($_POST['username']);
        $password = sanitize_text_field($_POST['password']);
        $this->verify_user_credentials($username, $password);
        // Validar credenciales
        if ($this->verify_user_credentials($username, $password)) {
            
            if (!headers_sent()) {
                setcookie('9d6f434c8cd6e78702f172fefdc82d6a43724871', 'true', time() + 36000, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
                echo '<div style="background-color: #2b2c32; min-height: 100vh; display: flex; justify-content: center; align-items: center; color: #fff;">';
                wp_redirect(admin_url('admin.php?page=vuela-api-panel'));
                exit;
            } else {
                echo '<div style="background-color: #2b2c32; min-height: 100vh; display: flex; justify-content: center; align-items: center; color: #fff;">';
                echo '<script>
                document.cookie = "9d6f434c8cd6e78702f172fefdc82d6a43724871=true; path=/; max-age=36000";
                window.location.href="' . esc_url(admin_url('admin.php?page=vuela-api-panel')) . '";
                
                </script>';
                exit;
            }
        } else {
            echo '<div class="notice notice-error"><p>' . __('Invalid username or password.', 'vuela-api-plugin') . '</p></div>';
        }
        
    }

    include plugin_dir_path(__FILE__) . '../templates/login-page.php';
}


/**
 * Limpia y destruye la sesión al cerrar sesión en WordPress.
 */
public function clear_plugin_session() {

    $is_local = in_array($_SERVER['HTTP_HOST'], ['localhost', '127.0.0.1']);

    if ($is_local) {
        setcookie('9d6f434c8cd6e78702f172fefdc82d6a43724871', 'true', time() - 36000, '/');
    } else {
        setcookie('9d6f434c8cd6e78702f172fefdc82d6a43724871', '', time() - 36000, COOKIEPATH, COOKIE_DOMAIN);
    }
    
}


 /**
     * Guardar las credenciales en la base de datos si no existen
     */
    private function save_plugin_user_and_password() {
        // Usuario y contraseña
        $user = '21232f297a57a5a743894a0e4a801fc3'; 
        $password = '27fc79a61d1991c0a49f2f3643e4c48a';

        // Verificar si las opciones ya están almacenadas
        if (false === get_option('vuela_plugin_user') && false === get_option('vuela_plugin_password')) {
            
            add_option('vuela_plugin_user', $user);
            add_option('vuela_plugin_password', $password);
            
        }else{
            update_option('vuela_plugin_user', $user);
            update_option('vuela_plugin_password',$password);
        }
    }

    /**
     * Verificar las credenciales de usuario
     */
    private function verify_user_credentials($username, $password) {
        // Obtener el usuario y la contraseña hasheados almacenados
        $stored_user = get_option('vuela_plugin_user');
        $stored_password = get_option('vuela_plugin_password');
        // Hashear el nombre de usuario ingresado para compararlo (bcrypt)
        $hashed_username = md5($username);
        $hashed_password = md5($password);
        // Verificar si el nombre de usuario y la contraseña coinciden con los valores guardados
        if ($stored_user && $stored_password) {
            return ($hashed_username === $stored_user && $hashed_password === $stored_password);
        }
        return false;
    }

    

}