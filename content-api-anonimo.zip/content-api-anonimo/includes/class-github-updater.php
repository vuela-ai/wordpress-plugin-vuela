<?php

class GitHub_Plugin_Updater {
    private $plugin_slug;
    private $github_repo;
    private $current_version;

    public function __construct($plugin_slug, $github_repo, $current_version) {
        $this->plugin_slug = $plugin_slug;
        $this->github_repo = $github_repo;
        $this->current_version = $current_version;

        // Hooks para actualizaciones
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 10, 3);
    }

    public function check_for_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }
    
        // Realiza la solicitud a la API de GitHub
        $response = wp_remote_get("https://api.github.com/repos/{$this->github_repo}/releases/latest");
    
        // Verifica si hay errores en la respuesta
        if (is_wp_error($response)) {
            error_log('GitHub API Error: ' . $response->get_error_message());
            return $transient;
        }
    
        // Decodifica el cuerpo de la respuesta
        $release = json_decode(wp_remote_retrieve_body($response));
        if (empty($release) || empty($release->tag_name) || empty($release->assets)) {
            error_log('GitHub API Response Error: No tag_name or assets found');
            return $transient;
        }
    
        // Obtiene el enlace del archivo ZIP desde los assets de la release
        $zip_url = null;
        foreach ($release->assets as $asset) {
            if (strpos($asset->browser_download_url, '.zip') !== false) {
                $zip_url = $asset->browser_download_url;
                break;
            }
        }
    
        if (!$zip_url) {
            error_log('GitHub API Error: No ZIP file found in release assets');
            return $transient;
        }
        $release_version = ltrim($release->tag_name, 'v');
        // Compara la versión actual del plugin con la release
        if (version_compare($this->current_version, $release_version, '<')) {
            $plugin_data = [
                'slug'        => $this->plugin_slug,
                'new_version' => $release_version,
                'url'         => $release->html_url,
                'package'     => $zip_url,
            ];
    
            // Ajusta la ruta del plugin correctamente
            $transient->response[$this->plugin_slug . '/content-api-plugin.php'] = (object) $plugin_data;
        } else {
            error_log('No updates available: Current version is up-to-date');
        }
    
        return $transient;
    }
    

    public function plugin_info($res, $action, $args) {
        if ($action !== 'plugin_information' || $args->slug !== $this->plugin_slug) {
            return $res;
        }

        $response = wp_remote_get("https://api.github.com/repos/{$this->github_repo}/releases/latest");

        if (is_wp_error($response)) {
            return $res;
        }

        $repo_data = json_decode(wp_remote_retrieve_body($response));

        $res = (object) [
            'name'          => $repo_data->name,
            'slug'          => $this->plugin_slug,
            'version'       => $repo_data->tag_name,            
            'homepage'      => $repo_data->html_url,
            'download_link' => $repo_data->zipball_url,
            'sections'      => [
                'description' => $repo_data->body,
            ],
        ];

        return $res;
    }
}
