<?php

// Registrar configuraciones.
function vuela_api_register_settings() {
    register_setting('vuela_api_settings', 'vuela_api_token', 'sanitize_text_field');

    add_settings_section(
        'vuela_api_main_section',
        __('API Settings', 'vuela-api-plugin'),
        'vuela_api_main_section_callback',
        'vuela-api-settings'
    );

    add_settings_field(
        'vuela_api_token',
        __('API Token', 'vuela-api-plugin'),
        'vuela_api_token_callback',
        'vuela-api-settings',
        'vuela_api_main_section'
    );
}
add_action('admin_init', 'vuela_api_register_settings');

function vuela_api_main_section_callback() {
    echo '<p>' . __('Enter your Vuela API token below:', 'vuela-api-plugin') . '</p>';
}

function vuela_api_token_callback() {
    $token = get_option('vuela_api_token', '');
    echo '<input type="text" id="vuela_api_token" name="vuela_api_token" value="' . esc_attr($token) . '" size="50" />';
}

// Manejar la validación del token via AJAX.
function vuela_api_validate_token() {
    check_ajax_referer('vuela_api_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Unauthorized', 'vuela-api-plugin')]);
    }

    $token = sanitize_text_field($_POST['token']);

    // Realizar la solicitud a la API de Vuela.
    $response = wp_remote_post('https://api.vuela.ai/generate/validate-token', [
        'headers' => [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
        ],
        'body'    => json_encode([]),
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error(['message' => $response->get_error_message()]);
    }

    $status_code = wp_remote_retrieve_response_code($response);

    if ($status_code === 200) {
        wp_send_json_success(['message' => __('Token is valid.', 'vuela-api-plugin')]);
    } else {
        wp_send_json_error(['message' => __('Invalid token.', 'vuela-api-plugin')]);
    }
}
add_action('wp_ajax_vuela_api_validate_token', 'vuela_api_validate_token');



function vuela_is_token_valid() {
    $token = get_option('vuela_api_token', '');
    
    // Retornar false si no hay token
    if (!$token) {
        return false;
    }

    // Llamar a la API para validar el token
    $response = wp_remote_post('https://api.vuela.ai/generate/validate-token', [
        'headers' => [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
        ],
        'body'    => json_encode([]),
    ]);

    // Verificar errores de la API y el código de respuesta
    if (is_wp_error($response)) {
        return false;
    }

    $status_code = wp_remote_retrieve_response_code($response);
    return $status_code === 200;
}


add_action('wp_ajax_generate_informative_article', 'generate_informative_article_callback');
function generate_informative_article_callback() {
    // Verificar nonce para seguridad
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'vuela_api_article_generation')) {
        wp_send_json_error(['message' => __('Invalid request.', 'vuela-api-plugin')]);
        return;
    }

    // Obtener datos del formulario
    $inputType = isset($_POST['input_type']) ? sanitize_text_field($_POST['input_type']) : '';
    $inputField = isset($_POST['input_field']) ? sanitize_textarea_field($_POST['input_field']) : ''; // Puede ser un bloque de texto (bulk)
    $language = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : 'en';
    $country = isset($_POST['country']) ? sanitize_text_field($_POST['country']) : 'US';
    $focus = isset($_POST['focus']) ? sanitize_textarea_field($_POST['focus']) : '';
    $publish_directly = isset($_POST['publish_directly']) ? intval($_POST['publish_directly']) : 0;

    // Verificar si se proporciona un campo válido
    if (empty($inputField)) {
        wp_send_json_error(['message' => __('Either the title or the keyword must be provided.', 'vuela-api-plugin')]);
        return;
    }

    //Dividir el campo en varias líneas si es modo bulk
    $input_lines = explode("\n", trim($inputField)); // Cada línea será un nuevo artículo

    $token = get_option('vuela_api_token', '');

    // Iterar sobre cada línea para crear múltiples artículos
    $article_ids = [];
    foreach ($input_lines as $line) {
        $line = trim($line);
        if (empty($line)) continue; //Omitir líneas vacías

        //Preparar los datos para la API
        $api_data = [
            'title' => ($inputType === 'title') ? $line : '',
            'keyword' => ($inputType === 'keyword') ? $line : '',
            'language' => $language,
            'country' => $country,
            'focus' => $focus
        ];

        // Solo agregar 'add_images' e 'images_focus' si son necesarios
        if (isset($_POST['add_images']) && $_POST['add_images'] === 'true') {
            $api_data['add_images'] = true;
            if (!empty($_POST['images_focus'])) {
                $api_data['images_focus'] = sanitize_text_field($_POST['images_focus']);
            }
        }

        //Realizar la solicitud a la API para cada artículo
        $response = wp_remote_post('https://api.vuela.ai/generate/article', [
            'timeout' => 120,
            'body' => json_encode($api_data),
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ]
        ]);

        //Manejar la respuesta de la API
        if (is_wp_error($response)) {
            wp_send_json_error(['message' => __('Error connecting to API for line: ' . $line, 'vuela-api-plugin')]);
            return;
        }

        $response_body = wp_remote_retrieve_body($response);
        $result = json_decode($response_body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            wp_send_json_error(['message' => __('Error decoding API response for line: ' . $line, 'vuela-api-plugin')]);
            return;
        }

        // Validar si la API devolvió un error o insuficientes créditos
        if (isset($result['status']) && $result['status'] === 'error') {
            $error_message = $result['message'];

            // Intentar traducir el mensaje de error
            $error_message = __($error_message, 'vuela-api-plugin');

            wp_send_json_error(['message' => $error_message]);
            
            return;
        }

        // Usar título o keyword
        $title = !empty($api_data['title']) ? $api_data['title'] : $api_data['keyword'];

        // Insertar el post
        $post_id = insert_post_with_meta($title, $result, $publish_directly);

        if (is_wp_error($post_id)) {
            wp_send_json_error(['message' => __('Failed to create post for line: ' . $line, 'vuela-api-plugin')]);
            return;
        }

        $article_ids[] = $post_id;
    }

    // Respuesta exitosa
    wp_send_json_success([
        'success' => true,
        'message' => sprintf(
        //__('%d article(s) generated successfully, pending completion.', 'vuela-api-plugin'),count($article_ids)),
        __('We are generating the content. This process may take up to 10 minutes while we gather and organize information sources. The article will not appear in your WordPress until we have finished.', 'vuela-api-plugin')),
        'link' => admin_url('admin.php?page=vuela-api-panel&section=my-content'),
        'article_ids' => $article_ids
    ]);
}


// Función auxiliar para insertar el post con metadatos
function insert_post_with_meta($title, $result, $publish_directly) {
    // Crear el post
    $new_post = [
        'post_title'   => $title,
        'post_status'  => 'vuela',
        'post_type'    => 'post'
    ];

    $post_id = wp_insert_post($new_post);

    if (is_wp_error($post_id)) {
        return $post_id; 
    }

    // Guardar los metadatos
    update_post_meta($post_id, 'idcontenvuela', sanitize_text_field($result['data']['id']));
    update_post_meta($post_id, 'statusvuela', sanitize_text_field($result['data']['status']));
    update_post_meta($post_id, 'statuspostvuela', $publish_directly);

    
    wp_schedule_single_event(time() + 300, 'check_vuela_article_status_single', [$post_id]);

    return $post_id;
}




//Logica para obtener el articulo
// Acción del cron para verificar el estado de artículos con estado 'creating'
add_action('check_vuela_article_status_single', 'check_vuela_article_status_single_callback');
function check_vuela_article_status_single_callback() {
    $args = [
        'post_type'   => 'post',
        'post_status' => 'vuela',
        'meta_query'  => [
            [
                'key'     => 'statusvuela',
                'value'   => 'creating',
                'compare' => '='
            ]
        ]
    ];

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $post_id = get_the_ID();
            $api_id = get_post_meta($post_id, 'idcontenvuela', true);
            $statuspostvuela = get_post_meta($post_id, 'statuspostvuela', true);
            $status_post = ($statuspostvuela === '1') ? 'publish' : 'draft';

            // Verificar el estado del artículo en la API
            $token = get_option('vuela_api_token', '');
            $response = wp_remote_get("https://api.vuela.ai/my-content/$api_id", [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ]
            ]);

            if (!is_wp_error($response)) {
                $response_body = wp_remote_retrieve_body($response);
                $result = json_decode($response_body, true);

                // Verificar si la respuesta de la API es exitosa y si el estado es 'complete'
                if ($result['status'] === 'success' && $result['data']['status'] === 'completed') {
                    $content = $result['data']['response']['content'];
                    $content_img = process_base64_images($content, $post_id);
                    if (!empty($result['data']['parameters']['keyword'])) {
                        $new_title = $result['data']['response']['title']; // Título actualizado
                    } else {
                        $new_title = get_the_title($post_id); // Mantener el título actual
                    }
                    
                    
                    // Actualizar el contenido del post con la respuesta de la API
                    wp_update_post([
                        'ID'           => $post_id,
                        'post_content' => $content_img,
                        'post_status'  => $status_post,
                        'post_title'   => $new_title
                    ]);

                    // Actualizar el estado en los metadatos del post
                    update_post_meta($post_id, 'statusvuela', 'complete');
                }else if ($result['status'] === 'success' && $result['data']['status'] === 'failed') {
                    // Actualizar el contenido del post con la respuesta de la API
                    wp_update_post([
                        'ID'           => $post_id,
                        'post_content' => $result['data']['response']['content'],
                         
                    ]);

                    // Actualizar el estado en los metadatos del post
                    update_post_meta($post_id, 'statusvuela', 'failed');
                } else {
                    // Reprogramar el cron para volver a verificar en 5 minutos si no está completo
                    wp_schedule_single_event(time() + 300, 'check_vuela_article_status_single');
                }
            }
        }
    }
    wp_reset_postdata();
}


function get_vuela_content($page = 1, $search = '', $status = '', $type = '', $project_id='') {
    $token = get_option('vuela_api_token', '');

    // Obtener el dominio desde la URL del sitio
    $site_url = home_url(); 
    $parsed_url = parse_url($site_url);
    $domain = $parsed_url['host'];
    //$domain="mhiel.mx";
   
    $api_data = [
        'page' => $page,
        'limit' => 10,
        'search' => $search,
        'status' => $status,
        'type' => $type,
        'project' => $project_id,
        'project_domain' =>$domain
    ];

    // Convertimos los parámetros en una cadena de consulta (query string)
    $query_string = http_build_query($api_data);

    // Hacemos la solicitud GET incluyendo los parámetros en la URL
    $response = wp_remote_get('https://api.vuela.ai/my-content?' . $query_string, [
        'timeout' => 60,
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ],
    ]);

    if (is_wp_error($response)) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    return json_decode($body, true);
}


function get_vuela_project() {
    $token = get_option('vuela_api_token', '');

    // Obtener el dominio desde la URL del sitio
    $site_url = home_url(); 
    $parsed_url = parse_url($site_url);
    $domain = $parsed_url['host'];
    //$domain="mhiel.mx";

    $api_data = [
        'search' =>$domain
    ];

    // Convertimos los parámetros en una cadena de consulta (query string)
    $query_string = http_build_query($api_data);

    // Hacemos la solicitud GET incluyendo los parámetros en la URL
    $response = wp_remote_get('https://api.vuela.ai/my-projects?' . $query_string, [
        'timeout' => 60,
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ],
    ]);

    if (is_wp_error($response)) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    return json_decode($body, true);
}

/**************Images****************/

/**
 * Procesar imágenes en base64 y subirlas a la galería de medios de WordPress
 * @param string $content El contenido con imágenes base64.
 * @param int $post_id El ID del post donde se guardarán las imágenes.
 * @return string El contenido con las URLs de imágenes procesadas.
 */
function process_base64_images($content, $post_id) {
    // Buscar todas las imágenes base64 en el contenido
    //preg_match_all('/<img.*?src=["\'](data:image\/(.*?);base64,.*?)["\'].*?(\/?)>/i', $content, $matches);
    preg_match_all('/<img.*?src=["\'](data:image\/(.*?);base64,[^"\']+)["\'][^>]*\/?>/', $content, $matches);

    if (empty($matches[1])) {
        return $content; // No hay imágenes en base64 en el contenido.
    }

    $image_urls = [];
    $is_first_image = true; // Indicador para la primera imagen

    foreach ($matches[1] as $index => $base64_image) {
        // Extraer el tipo de imagen (jpeg, png, etc.)
        preg_match('/data:image\/(.*?);base64,/', $base64_image, $mime_match);
        $mime_type = $mime_match[1];

        // Decodificar la cadena base64
        $image_data = base64_decode(preg_replace('/^data:image\/(.*?);base64,/', '', $base64_image));

        // Comprobar si la decodificación fue exitosa
        if ($image_data === false) {
            error_log("Error al decodificar la imagen en base64 para el post ID: $post_id, índice: $index");
            continue; // Saltar esta imagen si falla la decodificación
        }

        // Generar un nombre único para la imagen
        $upload_dir = wp_upload_dir();
        $image_name = uniqid('vuela_img_') . '.' . ($mime_type === 'jpeg' ? 'jpg' : $mime_type);

        // Guardar la imagen en el directorio de uploads de WordPress
        $image_path = $upload_dir['path'] . '/' . $image_name;
        if (file_put_contents($image_path, $image_data) === false) {
            error_log("Error al guardar la imagen en $image_path para el post ID: $post_id, índice: $index");
            continue; // Saltar si no se puede guardar la imagen
        }

        // Subir la imagen a la galería de medios de WordPress
        $wp_filetype = wp_check_filetype($image_name, null);
        $attachment = [
            'guid'           => $upload_dir['url'] . '/' . $image_name,
            'post_mime_type' => $wp_filetype['type'],
            'post_title'     => sanitize_file_name($image_name),
            'post_content'   => '',
            'post_status'    => 'inherit',
            'post_parent'    => $post_id, // Asociar la imagen al post
        ];

        $attach_id = wp_insert_attachment($attachment, $image_path, $post_id);
        if (is_wp_error($attach_id)) {
            error_log("Error al insertar la imagen adjunta para el post ID: $post_id, índice: $index, error: " . $attach_id->get_error_message());
            continue; // Saltar si falla la inserción
        }

        // Procesar la imagen para que se incluya en la biblioteca de medios
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $image_path);
        wp_update_attachment_metadata($attach_id, $attach_data);

        // Generar la URL de la imagen
        $image_url = wp_get_attachment_url($attach_id);

        // Si es la primera imagen, la asignamos como imagen destacada y la eliminamos del contenido
        if ($is_first_image) {
            set_post_thumbnail($post_id, $attach_id);
            $is_first_image = false; // Marcar que ya se procesó la primera imagen

            // Eliminar la primera imagen del contenido
            $content = str_replace($matches[0][$index], '', $content);
        } else {
            // Crear la nueva etiqueta <img> con la URL en lugar de base64
            $new_img_tag = '<img src="' . esc_url($image_url) . '" style="max-width: 100%; height: auto;" />';
            // Reemplazar la imagen base64 con la nueva etiqueta de imagen
            $content = str_replace($matches[0][$index], $new_img_tag, $content);
        }

        // Agregar la URL de la imagen al array
        $image_urls[] = $image_url;
    }

    return $content;
}

add_action('wp_ajax_import_informative_article', 'insert_post_import_article');
function insert_post_import_article() {
    // Verificar nonce para seguridad
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'vuela_api_article_import')) {
        wp_send_json_error(['message' => __('Invalid request.', 'vuela-api-plugin')]);
        return;
    }

    $publish_directly = $_POST['publish_directly'];
    $status_post = ($publish_directly === '1') ? 'publish' : 'draft';
    $id_content = $_POST['id_content'];
    $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : 'post';

    $token = get_option('vuela_api_token', '');
    $response = wp_remote_get("https://api.vuela.ai/my-content/$id_content", [
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token,
        ]
    ]);

     $is_webp_supported=false;
    if (is_webp_supported()) {
        $is_webp_supported=true;
    } else {
        $is_webp_supported=false;
    }

    if (!is_wp_error($response)) {
        $response_body = wp_remote_retrieve_body($response);
        $response_body = mb_convert_encoding($response_body, 'HTML-ENTITIES', 'UTF-8');
        $result = json_decode($response_body, true);

        if ($result['status'] === 'success' && $result['data']['status'] === 'completed') {
            $content = $result['data']['response']['content'];
            /*if (!empty($result['data']['parameters']['keyword'])) {
                $new_title = $result['data']['response']['title']; // Título actualizado
            } else {
                $new_title = $result['data']['parameters']['title'];
            } */

            $new_title = $result['data']['response']['seo_title']; // Título actualizado

            // Procesar imágenes del contenido
            $doc = new DOMDocument();
            @$doc->loadHTML($content);
            $images = $doc->getElementsByTagName('img');
            $first_image_url = null;

            if ($images->length > 0) {
                // Obtener la URL de la primera imagen
                $first_image_url = $images->item(0)->getAttribute('src');

                // Remover la primera imagen del contenido
                $images->item(0)->parentNode->removeChild($images->item(0));
            }

            // Aplicar estilo a todas las imágenes restantes
            foreach ($images as $image) {
                $existing_style = $image->getAttribute('style');
                $new_style = 'max-width:100%; height:auto;' . $existing_style;
                $image->setAttribute('style', $new_style);
            }


            $post_content = '';
            foreach ($doc->getElementsByTagName('body')->item(0)->childNodes as $child) {
                $post_content .= $doc->saveHTML($child);
            }

            if ($post_type === 'post') {
            // Crear el post
            $new_post = [
                'post_title'   => $new_title,
                'post_content' => $post_content,
                'post_status'  => $status_post,
                'post_type'    => 'post',
            ];

            }else if ($post_type === 'page') {
                // Lógica para crear una página
                $new_post = [
                    'post_title'   => $new_title,
                    'post_content' => $post_content,
                    'post_status'  => $status_post,
                    'post_type'    => 'page',
                ];               
            }

            $post_id = wp_insert_post($new_post);

            if (!is_wp_error($post_id)) {
                // Descargar y guardar la primera imagen como destacada
                if ($first_image_url) {
                    $featured_image_id = media_sideload_image($first_image_url, $post_id, null, 'id');
                    if (!is_wp_error($featured_image_id)) {
                        if($is_webp_supported==false){
                            set_post_thumbnail($post_id, $featured_image_id);
                        }else{
                            $original_image_path = get_attached_file($featured_image_id);
                            $webp_image_path = convert_image_to_webp($original_image_path);
                            if ($webp_image_path) {
                                wp_delete_attachment($featured_image_id, true);
                                // Subir la imagen WebP como la imagen destacada
                                $webp_attachment_id = media_handle_sideload([
                                    'tmp_name' => $webp_image_path,
                                    'name'     => basename($webp_image_path),
                                ], $post_id);
                                set_post_thumbnail($post_id, $webp_attachment_id);
                            }
                        }
                        
                    }
                }

                // Descargar y guardar todas las demás imágenes en el contenido
                foreach ($images as $image) {
                    $img_url = $image->getAttribute('src');
                    $attachment_id = media_sideload_image($img_url, $post_id, null, 'id');
                    if (!is_wp_error($attachment_id)) {
                        
                        if($is_webp_supported==false){
                        $new_url = wp_get_attachment_url($attachment_id);
                        $image->setAttribute('src', $new_url);
                        }else{
                            $original_image_path = get_attached_file($attachment_id);
                            $webp_image_path = convert_image_to_webp($original_image_path);
                            
                            if ($webp_image_path) {
                                wp_delete_attachment($attachment_id, true);
                                $webp_attachment_id = media_handle_sideload([
                                    'tmp_name' => $webp_image_path,
                                    'name'     => basename($webp_image_path),
                                ], $post_id);
                                if (!is_wp_error($webp_attachment_id)) {
                                    // Obtener la nueva URL y actualizar el atributo src
                                    $new_url = wp_get_attachment_url($webp_attachment_id);
                                    $image->setAttribute('src', $new_url); // Actualizar src
                                }
                            } 
                        }
                    }
                }

                $post_content = '';
                foreach ($doc->getElementsByTagName('body')->item(0)->childNodes as $child) {
                    $post_content .= $doc->saveHTML($child);
                }
                // Actualizar el contenido del post con las nuevas URLs
                wp_update_post([
                    'ID'           => $post_id,
                    'post_content' => $post_content,
                ]);

                //Meta
                $meta_description=$result['data']['response']['seo_description'];
                update_post_meta($post_id, 'vuela_meta_description', $meta_description);

                vuela_import_content($id_content);

                // Respuesta exitosa
                wp_send_json_success([
                    'success' => true,
                    'message' => sprintf(            
                    __('Great! Your article is created.', 'vuela-api-plugin')),
                    'link' => get_permalink($post_id),            
                ]);
                return;
            }
        }
    }

    wp_send_json_error(['message' => __('Failed to create post.', 'vuela-api-plugin')]);
}



add_action('wp_ajax_import_informative_article_select', 'insert_post_import_article_select');
function insert_post_import_article_select() {

    // Verificar nonce para seguridad
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'vuela_api_article_import')) {
        wp_send_json_error(['message' => __('Invalid request.', 'vuela-api-plugin')]);
        return;
    }

    $publish_directly = $_POST['publish_directly'];
    $status_post = ($publish_directly === '1') ? 'publish' : 'draft';
    $ids_content = isset($_POST['ids_content']) ? $_POST['ids_content'] : [];
    $post_type = isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : 'post';

    $is_webp_supported=false;
    if (is_webp_supported()) {
        $is_webp_supported=true;
    } else {
        $is_webp_supported=false;
    }

    if (empty($ids_content)) {
        wp_send_json_error(['message' => __('No content selected.', 'vuela-api-plugin')]);
        return;
    }

    $token = get_option('vuela_api_token', '');
    $successful_imports = [];

    foreach ($ids_content as $id_content) {
        $response = wp_remote_get("https://api.vuela.ai/my-content/$id_content", [
            'timeout' => 120,
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ]
        ]);

        if (!is_wp_error($response)) {
            $response_body = wp_remote_retrieve_body($response);
            $response_body = mb_convert_encoding($response_body, 'HTML-ENTITIES', 'UTF-8');
            $result = json_decode($response_body, true);

            if ($result['status'] === 'success' && $result['data']['status'] === 'completed') {
                $content = $result['data']['response']['content'];
                //$new_title = !empty($result['data']['parameters']['keyword']) ? $result['data']['response']['title'] : $result['data']['parameters']['title'];
                $new_title = $result['data']['response']['seo_title']; // Título actualizado
                // Procesar imágenes del contenido
                $doc = new DOMDocument();
                @$doc->loadHTML($content);
                $images = $doc->getElementsByTagName('img');
                $first_image_url = null;

                if ($images->length > 0) {
                    $first_image_url = $images->item(0)->getAttribute('src');
                    $images->item(0)->parentNode->removeChild($images->item(0));
                }

                foreach ($images as $image) {
                    $existing_style = $image->getAttribute('style');
                    $new_style = 'max-width:100%; height:auto;' . $existing_style;
                    $image->setAttribute('style', $new_style);
                }

                $post_content = '';
                foreach ($doc->getElementsByTagName('body')->item(0)->childNodes as $child) {
                    $post_content .= $doc->saveHTML($child);
                }

                if ($post_type === 'post') {
                    // Crear el post
                    $new_post = [
                        'post_title'   => $new_title,
                        'post_content' => $post_content,
                        'post_status'  => $status_post,
                        'post_type'    => 'post',
                    ];
        
                    }else if ($post_type === 'page') {
                        // Lógica para crear una página
                        $new_post = [
                            'post_title'   => $new_title,
                            'post_content' => $post_content,
                            'post_status'  => $status_post,
                            'post_type'    => 'page',
                        ];               
                    }

                
                $post_id = wp_insert_post($new_post);

                if (!is_wp_error($post_id)) {
                // Descargar y guardar la primera imagen como destacada
                if ($first_image_url) {
                    $featured_image_id = media_sideload_image($first_image_url, $post_id, null, 'id');
                    if (!is_wp_error($featured_image_id)) {
                        if($is_webp_supported==false){
                            set_post_thumbnail($post_id, $featured_image_id);
                        }else{
                            $original_image_path = get_attached_file($featured_image_id);
                            $webp_image_path = convert_image_to_webp($original_image_path);
                            if ($webp_image_path) {
                                wp_delete_attachment($featured_image_id, true);
                                // Subir la imagen WebP como la imagen destacada
                                $webp_attachment_id = media_handle_sideload([
                                    'tmp_name' => $webp_image_path,
                                    'name'     => basename($webp_image_path),
                                ], $post_id);
                                set_post_thumbnail($post_id, $webp_attachment_id);
                            }
                        }
                        
                    }
                }

                // Descargar y guardar todas las demás imágenes en el contenido
                foreach ($images as $image) {
                    $img_url = $image->getAttribute('src');
                    $attachment_id = media_sideload_image($img_url, $post_id, null, 'id');
                    if (!is_wp_error($attachment_id)) {
                        
                        if($is_webp_supported==false){
                        $new_url = wp_get_attachment_url($attachment_id);
                        $image->setAttribute('src', $new_url);
                        }else{
                            $original_image_path = get_attached_file($attachment_id);
                            $webp_image_path = convert_image_to_webp($original_image_path);
                            
                            if ($webp_image_path) {
                                wp_delete_attachment($attachment_id, true);
                                $webp_attachment_id = media_handle_sideload([
                                    'tmp_name' => $webp_image_path,
                                    'name'     => basename($webp_image_path),
                                ], $post_id);
                                if (!is_wp_error($webp_attachment_id)) {
                                    // Obtener la nueva URL y actualizar el atributo src
                                    $new_url = wp_get_attachment_url($webp_attachment_id);
                                    $image->setAttribute('src', $new_url); // Actualizar src
                                }
                            } 
                        }
                    }
                }

                    $post_content = '';
                    foreach ($doc->getElementsByTagName('body')->item(0)->childNodes as $child) {
                        $post_content .= $doc->saveHTML($child);
                    }
                    //Meta
                    $meta_description=$result['data']['response']['seo_description'];
                    update_post_meta($post_id, 'vuela_meta_description', $meta_description);
                    
                    wp_update_post([
                        'ID'           => $post_id,
                        'post_content' => $post_content,
                    ]);

                    vuela_import_content($id_content);

                    $successful_imports[] = get_permalink($post_id);
                }
            }
        }
    }

    if (!empty($successful_imports)) {
        if ($post_type === 'post') {
           
            $linkfinal=admin_url('edit.php');

            }else if ($post_type === 'page') {
            
                $linkfinal=admin_url('edit.php?post_type=page');
            }
        
        wp_send_json_success([
            'success' => true,
            'message' => __('Great! Your articles have been created.', 'vuela-api-plugin'),
            'links' => $linkfinal
        ]);
    } else {
        wp_send_json_error(['message' => __('Failed to create posts.', 'vuela-api-plugin')]);
    }
}

function is_webp_supported_gd() {
    if (!function_exists('gd_info')) {
        return false; // GD no está habilitado
    }

    $gd_info = gd_info();
    return isset($gd_info['WebP Support']) && $gd_info['WebP Support'] === true;
}

function is_webp_supported_imagick() {
    if (!class_exists('Imagick')) {
        return false; // Imagick no está habilitado
    }

    $imagick = new Imagick();
    $formats = $imagick->queryFormats('WEBP');
    return in_array('WEBP', $formats);
}

function is_webp_supported() {
    return is_webp_supported_gd() || is_webp_supported_imagick();
}


add_action('wp_head', 'add_vuela_meta_tags');

function add_vuela_meta_tags() {
    if (is_single()||is_page()) { // Solo en entradas individuales
        global $post;

        
        // Obtener los metadatos personalizados
        $meta_description = get_post_meta($post->ID, 'vuela_meta_description', true);
               
        // Meta Description
        if ($meta_description) {
            echo '<meta name="description" content="' . esc_attr($meta_description) . '">';
        }
    }
}

// Función para convertir una imagen a WebP usando GD
function convert_image_to_webp($image_path) {
    // Obtener la extensión de la imagen
    $image_info = getimagesize($image_path);
    $image_type = $image_info[2]; // Tipo de la imagen: JPG, PNG, GIF, etc.

    if ($image_type == IMAGETYPE_JPEG) {
        // Cargar la imagen JPEG
        $image = imagecreatefromjpeg($image_path);
    } elseif ($image_type == IMAGETYPE_PNG) {
        // Cargar la imagen PNG
        $image = imagecreatefrompng($image_path);
    } elseif ($image_type == IMAGETYPE_GIF) {
        // Cargar la imagen GIF
        $image = imagecreatefromgif($image_path);
    } else {
        return false; // Si no es un formato soportado
    }

    // Definir el nuevo archivo WebP
    $webp_image_path = preg_replace('/\.(jpg|jpeg|png|gif)$/i', '.webp', $image_path);

    // Guardar la imagen en WebP
    imagewebp($image, $webp_image_path, 80); // Calidad de 0 a 100 (80 es un buen valor)
    imagedestroy($image); // Liberar memoria

    return $webp_image_path;
}

function vuela_api_disable_other_notices() {
    // Verifica que estás en la página de configuración de tu plugin.
    if (isset($_GET['page']) && ($_GET['page'] === 'vuela-api-settings' or $_GET['page'] === 'vuela-api-panel')) {
        // Elimina todos los mensajes que otros plugins hayan agregado.
        remove_all_actions('admin_notices');
    }
}
add_action('admin_head', 'vuela_api_disable_other_notices');

add_action('rest_api_init', function () {
    register_rest_route('vuela/v1', '/import-article', [
        'methods'             => ['GET', 'POST'],
        'callback'            => 'insert_post_import_article_api',
        'permission_callback' => '__return_true', // Ajusta según necesidades de seguridad.
    ]);
});



function insert_post_import_article_api(WP_REST_Request $request) {
    $params = $request->get_json_params();

    // Verificar el origen
    $allowed_domains = ['https://api.vuela.ai','https://vuela.ai'];
   
    $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : null;

    if ($request->get_method() === 'GET') {
        return new WP_REST_Response(['status' => 'active', 'message' => __('API is active.', 'vuela-api-plugin')], 200);
    }
    

    if (!$origin || !in_array($origin, $allowed_domains)) {
        return new WP_REST_Response(['message' => __('Unauthorized origin.', 'vuela-api-plugin')], 403);
    }

       // Verificar si las funciones necesarias están disponibles
       if ( ! function_exists( 'media_sideload_image' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/media.php' );
    }

    if ( ! function_exists( 'download_url' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
    }
    
    if ( ! function_exists( 'wp_read_image_metadata' ) ) {
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
    }
    // Validar el parámetro `bulk`
    $is_bulk = isset($params['bulk']) && $params['bulk'] === true;

    // Validar `publish_directly`
    if (!isset($params['publish_directly']) || !in_array($params['publish_directly'], ['draft', 'publish'])) {
        return new WP_REST_Response(['message' => __('Invalid publish_directly parameter.', 'vuela-api-plugin')], 400);
    }
    $publish_directly = $params['publish_directly'];
    $status_post = $publish_directly;

    // Validar tipo de post
    $post_type = isset($params['post_type']) ? sanitize_text_field($params['post_type']) : 'post';
    if (!in_array($post_type, ['post', 'page'])) {
        return new WP_REST_Response(['message' => __('Invalid post_type parameter.', 'vuela-api-plugin')], 400);
    }

    // Obtener los IDs de contenido
    $ids_content = $is_bulk ? (isset($params['id_content']) ? $params['id_content'] : []) : [$params['id_content']];

    if (empty($ids_content)) {
        return new WP_REST_Response(['message' => __('No content selected.', 'vuela-api-plugin')], 400);
    }

    $token = get_option('vuela_api_token', '');
    $successful_imports = [];
    $is_webp_supported = is_webp_supported();
    foreach ($ids_content as $id_content) {
        $response = wp_remote_get("https://api.vuela.ai/my-content/$id_content", [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ]
        ]);

        if (!is_wp_error($response)) {
            $response_body = wp_remote_retrieve_body($response);
            $response_body = mb_convert_encoding($response_body, 'HTML-ENTITIES', 'UTF-8');
            $result = json_decode($response_body, true);

            if ($result['status'] === 'success' && $result['data']['status'] === 'completed') {
                $content = $result['data']['response']['content'];
                $new_title = $result['data']['response']['seo_title'];

                // Procesar imágenes del contenido
                $doc = new DOMDocument();
                @$doc->loadHTML($content);
                $images = $doc->getElementsByTagName('img');
                $first_image_url = null;

                if ($images->length > 0) {
                    $first_image_url = $images->item(0)->getAttribute('src');
                    $images->item(0)->parentNode->removeChild($images->item(0));
                }

                foreach ($images as $image) {
                    $existing_style = $image->getAttribute('style');
                    $new_style = 'max-width:100%; height:auto;' . $existing_style;
                    $image->setAttribute('style', $new_style);
                }

                $post_content = '';
                foreach ($doc->getElementsByTagName('body')->item(0)->childNodes as $child) {
                    $post_content .= $doc->saveHTML($child);
                }

                // Crear el post
                $new_post = [
                    'post_title'   => $new_title,
                    'post_content' => $post_content,
                    'post_status'  => $status_post,
                    'post_type'    => $post_type,
                ];

                $post_id = wp_insert_post($new_post);

                if (!is_wp_error($post_id)) {
                    // Procesar imagen destacada
                    if ($first_image_url) {
                        $featured_image_id = media_sideload_image($first_image_url, $post_id, null, 'id');
                        if (!is_wp_error($featured_image_id)) {
                            if (!$is_webp_supported) {
                                set_post_thumbnail($post_id, $featured_image_id);
                            } else {
                                $original_image_path = get_attached_file($featured_image_id);
                                $webp_image_path = convert_image_to_webp($original_image_path);
                                if ($webp_image_path) {
                                    wp_delete_attachment($featured_image_id, true);
                                    $webp_attachment_id = media_handle_sideload([
                                        'tmp_name' => $webp_image_path,
                                        'name'     => basename($webp_image_path),
                                    ], $post_id);
                                    set_post_thumbnail($post_id, $webp_attachment_id);
                                }
                            }
                        }
                    }
    
                    foreach ($images as $image) {
                        $img_url = $image->getAttribute('src');
                        $attachment_id = media_sideload_image($img_url, $post_id, null, 'id');
                        if (!is_wp_error($attachment_id)) {
                            $original_image_path = get_attached_file($attachment_id);
                            $webp_image_path = $is_webp_supported ? convert_image_to_webp($original_image_path) : false;
    
                            if ($webp_image_path) {
                                wp_delete_attachment($attachment_id, true);
                                $webp_attachment_id = media_handle_sideload([
                                    'tmp_name' => $webp_image_path,
                                    'name'     => basename($webp_image_path),
                                ], $post_id);
                                if (!is_wp_error($webp_attachment_id)) {
                                    $new_url = wp_get_attachment_url($webp_attachment_id);
                                    $image->setAttribute('src', $new_url);
                                }
                            } else {
                                $new_url = wp_get_attachment_url($attachment_id);
                                $image->setAttribute('src', $new_url);
                            }
                        }
                    }
    
                    $post_content = '';
                    foreach ($doc->getElementsByTagName('body')->item(0)->childNodes as $child) {
                        $post_content .= $doc->saveHTML($child);
                    }
                    wp_update_post([
                        'ID'           => $post_id,
                        'post_content' => $post_content,
                    ]);

                    // Agregar meta descripción
                    update_post_meta($post_id, 'vuela_meta_description', $result['data']['response']['seo_description']);
                    vuela_import_content($id_content);
                    // Agregar al listado de importaciones exitosas
                    $successful_imports[] = get_permalink($post_id);
                }
            }
        }
    }

    if (!empty($successful_imports)) {
        $redirect_link = $post_type === 'post' ? admin_url('edit.php') : admin_url('edit.php?post_type=page');
        return new WP_REST_Response([
            'success' => true,
            'message' => __('Great! Your articles have been created.', 'vuela-api-plugin'),
            'links'   => $successful_imports,
        ], 200);
    }

    return new WP_REST_Response(['message' => __('Failed to create posts.', 'vuela-api-plugin')], 500);
}


function vuela_import_content($idcontent) {
    // URL de la API con el ID del contenido
    $api_url = "https://api.vuela.ai/my-content/{$idcontent}/import";

    // Obtener el token almacenado en las opciones de WordPress
    $token = get_option('vuela_api_token', '');

    // Verificar que el token exista
    if (empty($token)) {
        return new WP_Error('missing_token', __('El token de API no está configurado.', 'vuela'));
    }

    // Configuración de los headers
    $headers = [
        'Authorization' => 'Bearer ' . $token,
        'Content-Type'  => 'application/json',
    ];

    // Realizar la solicitud PUT sin cuerpo
    $response = wp_remote_request($api_url, [
        'method'    => 'PUT',
        'headers'   => $headers,
        'timeout'   => 15, // Ajusta el tiempo de espera según sea necesario
    ]);

    // Verificar si la solicitud tuvo éxito
    if (is_wp_error($response)) {
        return $response; // Devuelve el error
    }

    // Decodificar la respuesta
    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = json_decode(wp_remote_retrieve_body($response), true);

    return [
        'code' => $response_code,
        'body' => $response_body,
    ]; 
}