jQuery(document).ready(function($) {
    $('#validate-token').on('click', function(e) {
        e.preventDefault();

        const token = $('#vuela_api_token').val();

        $.ajax({
            url: VuelaAPI.ajax_url,
            method: 'POST',
            data: {
                action: 'vuela_api_validate_token',
                nonce: VuelaAPI.nonce,
                token: token
            },
            success: function(response) {
                if (response.success) {
                    $('#vuela-api-response').html('<div class="notice notice-success is-dismissible"><p>' + response.data.message + '</p></div>');
                } else {
                    $('#vuela-api-response').html('<div class="notice notice-error is-dismissible"><p>' + response.data.message + '</p></div>');
                }
            },
            error: function() {
                $('#vuela-api-response').html('<div class="notice notice-error is-dismissible"><p>' + VuelaAPI.error_message + '</p></div>');
            }
        });
    });
});


jQuery(document).ready(function($) {
    $('#toggleSwitch').change(function() {
        if ($(this).is(':checked')) {
            // Bulk mode
           
            $('#article_bulk_input_title').show();
            $('#article_bulk_input_keyword').show();
            $('#article_keyword').hide();
            $('#article_title').hide();
        } else {
            // Single mode
            $('#article_bulk_input_title').hide();
            $('#article_bulk_input_keyword').hide();
            $('#article_keyword').show();
            $('#article_title').show();
        }
    });
    $('#select_type').change(function() {        
        if ($(this).val()=='title') {
            
            $('.article_keyword').hide();
            $('.article_title').show();
        } else {
            
            $('.article_keyword').show();
            $('.article_title').hide();
        }
       
        
    });

     // Focus div toggle based on checkbox status
     $('#add_images').change(function() {
        var focusDiv = $('.images_focus');
        var textarea = $('#images_focus');

        if ($(this).is(':checked')) {
            focusDiv.show();  // Muestra el div cuando el checkbox está marcado
            textarea.show();  // Muestra el textarea
        } else {
            focusDiv.hide();  // Oculta el div cuando el checkbox no está marcado
            textarea.hide();  // Oculta el textarea
        }
    });

    $('#article-generation-form').on('submit', function(e) {
        e.preventDefault();

        let inputType = $('#select_type').val();
        let inputField = $('#toggleSwitch').is(':checked') 
            ? (inputType === 'title' ? $('#article_bulk_input_title').val() : $('#article_bulk_input_keyword').val())
            : (inputType === 'title' ? $('#article_title').val() : $('#article_keyword').val());

        const language = $('#article_language').val();
        const country = $('#article_country').val();
        const focus = $('#article_focus').val();
        const publishDirectly = $('#publish_directly').is(':checked') ? 1 : 0;
        const nonce = $('#vuela_api_nonce').val();

        
        const addImagesChecked = $('#add_images').is(':checked');
        const imagesFocus = $('#images_focus').val();

        if (!inputField) {
            alert(VuelaAPI.provide_title_or_keyword);
            return;
        }

        const submitButton = $(this).find('input[name="generate_article"]');
        submitButton.prop('disabled', true).val(VuelaAPI.processing_button_text);

        $('#vuela-api-response').html('<div class="notice notice-info"><p>'+VuelaAPI.processing_message+'</p></div>');
        
        // Construir los datos para enviar, incluyendo "add_images" y "images_focus"
        let requestData = {
            action: 'generate_informative_article',
            nonce: nonce,
            input_type: inputType,
            input_field: inputField,
            language: language,
            country: country,
            publish_directly: publishDirectly
        };

        // Agregar "add_images" solo si está marcado
        if (addImagesChecked) {
            requestData.add_images = true;  
            if (imagesFocus.trim()) {
                requestData.images_focus = imagesFocus;  
            }
        }

        $.ajax({
            url: VuelaAPI.ajax_url,
            method: 'POST',
            data: requestData,
            success: function(response) {
                if (response.success) {
                    $('#vuela-api-response').html('<div class="notice notice-success is-dismissible"><p>' + response.data.message + ' <a href="' + response.data.link + '">'+ VuelaAPI.view_request_status +'</a></p></div>');
                } else {
                    $('#vuela-api-response').html('<div class="notice notice-error is-dismissible"><p>' + response.data.message + '</p></div>');
                }
            },
            error: function() {
                $('#vuela-api-response').html('<div class="notice notice-error is-dismissible"><p>' + VuelaAPI.error_message + '</p></div>');
            },
            complete: function() {
                submitButton.prop('disabled', false).val(VuelaAPI.generate_button_text);
            }
        });
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const selectAllCheckbox = document.getElementById('select-all');
    const checkboxes = document.querySelectorAll('input[name="selected_contents[]"]');
   
    if (selectAllCheckbox) {
    selectAllCheckbox.addEventListener('change', function () {
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAllCheckbox.checked;
        });
    });}
});


function generate_article_import(button,idcontent){
    const nonce = jQuery('#vuela_api_nonce').val();
    const submitButton = jQuery(button);
    const buttonName = jQuery(button).attr('name');
    submitButton.prop('disabled', true).text(VuelaAPI.processing_button_text);
    const postTypeValue = jQuery('input[name="post_type"]:checked').val();
    const publishDirectly = jQuery('input[name="save_as"]:checked').val();
    
    let requestData = {
        action: 'import_informative_article',
        nonce: nonce,
        id_content: idcontent,
        publish_directly: publishDirectly === 'true' ? 1 : 0,
        post_type: postTypeValue
    };
    
    jQuery.ajax({
        url: VuelaAPI.ajax_url,
        method: 'POST',
        data: requestData,
        success: function(response) {
            if (response.success) {
                jQuery('#vuela-api-response').html('<div class="notice notice-success is-dismissible"><p>' + response.data.message + ' <a href="' + response.data.link + '" target="_BLANK">'+ VuelaAPI.check_request_here +'</a></p></div>');
            } else {
                jQuery('#vuela-api-response').html('<div class="notice notice-error is-dismissible"><p>' + response.data.message + '</p></div>');
            }
        },
        error: function() {
            jQuery('#vuela-api-response').html('<div class="notice notice-error is-dismissible"><p>' + VuelaAPI.error_message + '</p></div>');
            
                submitButton.prop('disabled', false).text(VuelaAPI.default_button_text_import);
                
        },
        complete: function() {
           
                submitButton.prop('disabled', false).text(VuelaAPI.default_button_text_import);
                
        }
    });


}

jQuery(document).ready(function($) {
    
    $('button[name="import_selected"],button[name="import_selected2"]').on('click', function() {
        // Obtener los IDs de los contenidos seleccionados
        var selectedContents = [];
        $('input[name="selected_contents[]"]:checked').each(function() {
            selectedContents.push($(this).val());
        });
        const submitButton = $(this);
        submitButton.prop('disabled', true).text(VuelaAPI.processing_button_text);
        const postTypeValue = $('input[name="post_type"]:checked').val();
        const publishDirectly = jQuery('input[name="save_as"]:checked').val();
        const buttonName = $(this).attr('name');
        

        // Verificar si hay contenidos seleccionados
        if (selectedContents.length === 0) {
            $('#vuela-api-response').html('<div class="notice notice-warning"><p>'+VuelaAPI.selected_contents+'</p></div>');            
            
                submitButton.prop('disabled', false).text(VuelaAPI.default_button_text_select);
                
            return;
        }
       

        // Realizar la llamada AJAX
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'import_informative_article_select',
                nonce: $('#vuela_api_nonce').val(),
                publish_directly: publishDirectly === 'true' ? 1 : 0,
                ids_content: selectedContents,
                post_type: postTypeValue
            },
            success: function(response) {
                if (response.success) {
                    $('#vuela-api-response').html('<div class="notice notice-success is-dismissible"><p>' + response.data.message + ' <a href="' + response.data.links + '">'+ VuelaAPI.check_request_here +'</a></p></div>');
                } else {
                    $('#vuela-api-response').html('<div class="notice notice-error is-dismissible"><p>' + response.data.message + '</p></div>');
                }
                
                submitButton.prop('disabled', false).text(VuelaAPI.default_button_text_select);
                
            },
            error: function() {
                $('#vuela-api-response').html('<div class="notice notice-error is-dismissible"><p>' + VuelaAPI.error_message + '</p></div>');
               
                    submitButton.prop('disabled', false).text(VuelaAPI.default_button_text_select);
                    
            },
            complete: function() {
                // Restaura el botón después de completar la solicitud
                
                    submitButton.prop('disabled', false).text(VuelaAPI.default_button_text_select);
                   
            }
        });
    });
});


jQuery(document).ready(function($) {
    // Función para verificar si hay algún checkbox marcado (considerando "Seleccionar todos")
    function isAnyCheckboxChecked() {
        // Verifica si el checkbox "Seleccionar todos" está marcado o si hay al menos un checkbox individual marcado
        if ($('#select-all').prop('checked')) {
            return true; // Si "Seleccionar todos" está marcado, todos los checkboxes están seleccionados
        }
        return $('input[name="selected_contents[]"]:checked').length > 0;
    }

    // Función para mostrar u ocultar el elemento con id="bulk-vuela"
    function toggleBulkVuela() {
        if (isAnyCheckboxChecked()) {
            $('#bulk-vuela').show();  // Muestra el elemento si hay algún checkbox marcado
        } else {
            $('#bulk-vuela').hide();  // Oculta el elemento si no hay checkboxes seleccionados
        }
    }

    // Verifica al cargar la página si hay algún checkbox marcado
    toggleBulkVuela();

    // Verifica cuando cambia el estado de los checkboxes
    $('input[name="selected_contents[]"], #select-all').on('change', function() {
        toggleBulkVuela();
    });

    // Cuando se marque o desmarque "Seleccionar todos", actualizar el estado de los checkboxes individuales
    $('#select-all').on('change', function() {
        if ($(this).prop('checked')) {
            $('input[name="selected_contents[]"]').prop('checked', true);
        } else {
            $('input[name="selected_contents[]"]').prop('checked', false);
        }
        toggleBulkVuela();  // Actualiza la visibilidad del elemento bulk-vuela
    });
});
