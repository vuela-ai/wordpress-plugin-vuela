<?php
/**
 * Plugin Name: Content Generator
 * Description: Professional writing tool for content and ecommerce.
 * Version: 1.0.2
 * Text Domain: vuela-api-plugin
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Prevents direct access.
}

require_once plugin_dir_path(__FILE__) . 'includes/class-vuela-api-plugin.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-github-updater.php';

function vuela_load_plugin_textdomain() {
    $language_path = dirname(plugin_basename(__FILE__)) . '/languages';
    load_plugin_textdomain('vuela-api-plugin', false, $language_path);
}
add_action('plugins_loaded', 'vuela_load_plugin_textdomain'); 



// Filtra la carga del archivo .mo para manejar dialectos específicos
add_filter('load_textdomain_mofile', 'custom_load_vuela_mofile', 10, 2);

function custom_load_vuela_mofile($mofile, $domain) {
    // Solo aplicar el filtro para nuestro dominio 'vuela-api-plugin'
    if ($domain !== 'vuela-api-plugin') {
        return $mofile;
    }

    // Obtén el código de idioma configurado en WordPress
    $locale = determine_locale();  // WordPress 5.0+ tiene esta función

    // Si es un dialecto de español (por ejemplo, es_AR, es_MX, etc.)
    if (strpos($locale, 'es_') === 0) {
        // Verifica si existe el archivo específico (por ejemplo, es_MX.mo)
        if (!file_exists($mofile)) {
            // Si no existe, intenta cargar el archivo genérico es.mo
            $generic_mofile = str_replace($locale, 'es', $mofile);
            if (file_exists($generic_mofile)) {
                return $generic_mofile;
            }
        }
    }

    // Retorna el archivo mofile original si no se hace ningún cambio
    return $mofile;
}


// Initialize the plugin.
function run_vuela_api_plugin() {
    global $vuela_api_plugin; // Declarar la variable global
    $vuela_api_plugin = new Vuela_API_Plugin(); // Crear la instancia y asignarla
    $vuela_api_plugin->run();

    
    // Verificación de actualizaciones solo en la página de plugins
    add_action('admin_init', function () {
        if (is_admin() && strpos($_SERVER['REQUEST_URI'], 'plugins.php') !== false) {
            
            // Forzar la verificación de actualizaciones
            wp_remote_get(admin_url('admin-ajax.php?action=check_for_plugin_updates'));
        }
    });
   
     // Inicializar actualizaciones desde GitHub
     if (is_admin()) {
        $plugin_file = plugin_basename(__FILE__);
        $plugin_slug = dirname($plugin_file);
        $github_repo = 'vuela-ai/wordpress-plugin-vuela-anonimo'; // Repositorio de GitHub
        $plugin_data = get_file_data(__FILE__, ['Version' => 'Version']);
        $current_version = $plugin_data['Version'];

        new GitHub_Plugin_Updater($plugin_slug, $github_repo, $current_version);
    }
}

run_vuela_api_plugin();