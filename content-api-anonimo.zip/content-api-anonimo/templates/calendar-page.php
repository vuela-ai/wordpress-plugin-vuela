
<div class="wrap" style="">
    <div class="playground-content" >
    <!--<h1><?php //echo esc_html__('Authentication', 'vuela-api-plugin'); ?></h1>-->
    
    <?php
    // Mostrar el formulario de login
   

    echo '<div class="wrap">';
    echo '<h1>' . __('Calendario de Publicaciones', 'vuela-api-plugin') . '</h1>';
    echo '<div id="vuela-calendar"></div>';
    echo '</div>';
    ?>
        
        
        
        
    </div>
</div>

    