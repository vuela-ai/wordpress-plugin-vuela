<?php
// Llama a la función para obtener los datos
$page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
$search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
$type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
$project_id = isset($_GET['project_id']) ? sanitize_text_field($_GET['project_id']) : '';

$vuela_data = get_vuela_content($page, $search, $status, $type, $project_id);
$vuela_data_projects = get_vuela_project();
$contents = $vuela_data['data']['contents']['docs'];
$total_pages = $vuela_data['data']['contents']['totalPages'];
?>

<?php wp_nonce_field('vuela_api_article_import', 'vuela_api_nonce'); ?>
<div class="wrap">
<?php if (!vuela_is_token_valid()) : ?>
        <div class="notice notice-warning">
            <p><?php _e('Add your API Key to use Vuela.', 'vuela-api-plugin'); ?></p>
        </div>
    <?php endif; ?>
    <div id="vuela-api-response"></div>
    <div class="content-card">
        <div class="card-body">
            <h1><?php echo esc_html__('Import your content from Vuela here!', 'vuela-api-plugin'); ?></h1>
            <div class="form-group">
                <h2><?php echo esc_html__('Select Post Type:', 'vuela-api-plugin'); ?></h2>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <label>
                        <input type="radio" name="post_type" value="post" checked />
                        <?php echo esc_html__('Post (entry)', 'vuela-api-plugin'); ?>
                    </label>
                    <label>
                        <input type="radio" name="post_type" value="page"  />
                        <?php echo esc_html__('Page', 'vuela-api-plugin'); ?>
                    </label>
                </div>
            </div>
            <div class="form-group">
                <h2><?php echo esc_html__('Choose the state:', 'vuela-api-plugin'); ?></h2>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <label>
                        <input type="radio" name="save_as" value="false" checked  />
                        <?php echo esc_html__('Draft', 'vuela-api-plugin'); ?>
                    </label>
                    <label>
                        <input type="radio" name="save_as" value="true"  />
                        <?php echo esc_html__('Publish', 'vuela-api-plugin'); ?>
                    </label>                    
                </div>
            </div>
            
             
            <div class="filters">
                <form method="get" action="">
                    <div class="form-row">
                        <div class="form-group">
                            <select name="project_id" id="dynamic-select" class="input-select">
                                <option value=""><?php echo esc_html__('All projects', 'vuela-api-plugin'); ?></option>
                                <?php
                                if (!empty($vuela_data_projects['data']['docs'])) {
                                    foreach ($vuela_data_projects['data']['docs'] as $project) {
                                        $selected = (isset($_GET['project_id']) && $_GET['project_id'] === $project['id']) ? 'selected' : '';
                                        echo '<option value="' . esc_attr($project['id']) . '" ' . $selected . '>' . esc_html($project['name']) . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <input placeholder="<?php echo esc_attr__('Search Content ID / Input', 'vuela-api-plugin'); ?>" class="input-text" type="text" name="search" value="<?php echo esc_attr($search); ?>">
                            <input type="hidden" name="page" value="vuela-api-panel">
                            <input type="hidden" name="section" value="my-content">
                        </div>
                        <div class="form-group">
                            <select name="type" class="input-select">
                                <option value="article" <?php selected($type, 'article'); ?>><?php echo esc_html__('Article', 'vuela-api-plugin'); ?></option>
                                <!--<option value="productDescription" <?php //selected($type, 'productDescription'); 
                                                                        ?>>Product</option>-->
                            </select>
                        </div>
                        <div class="form-group">
                            <select name="status" class="input-select">
                                <option value=""><?php echo esc_html__('All Status', 'vuela-api-plugin'); ?></option>
                                <option value="creating" <?php selected($status, 'creating'); ?>><?php echo esc_html__('Creating', 'vuela-api-plugin'); ?></option>
                                <option value="failed" <?php selected($status, 'failed'); ?>><?php echo esc_html__('Failed', 'vuela-api-plugin'); ?></option>
                                <option value="completed" <?php selected($status, 'completed'); ?>><?php echo esc_html__('Completed', 'vuela-api-plugin'); ?></option>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn-submit"><?php echo esc_html__('Filter', 'vuela-api-plugin'); ?></button>

                        </div>
                    </div>
                </form>
            </div>            
            <div id="bulk-vuela" style="display: none;">
            <div class="form-group" style="display:flex; align-items: center;justify-content: flex-start; gap: 10px;">
            <button type="button" name="import_selected" class="btn-submit"><?php echo esc_html__('Bulk import', 'vuela-api-plugin'); ?></button>
            <!-- Botón para programar publicaciones con ícono de reloj -->
            <button type="button" name="schedule_posts" class="btn-schedule btn-submit" style="margin-left: 10px;">
                <span class="dashicons dashicons-clock"></span>
            </button>
            </div>
            <div id="schedule-options-bulk" style="display: none;">
    <div class="form-row">
        <div class="form-group">
            <label for="start_date"><?php echo esc_html__('Initial date', 'vuela-api-plugin'); ?></label>
            <input type="date" id="start_date" name="start_date" class="form-control input-text">
        </div>
        <div class="form-group">
            <label for="schedule_time"><?php echo esc_html__('Publication time', 'vuela-api-plugin'); ?></label>
            <input type="time" id="schedule_time" name="schedule_time" class="form-control input-text">
        </div>

        <div class="form-group">
            <label for="frequency"><?php echo esc_html__('Frequency (days)', 'vuela-api-plugin'); ?></label>
            <input type="number" id="frequency" name="frequency" class="form-control input-text" min="1" style="width: 50px;">
        </div>

        <div class="form-group">
            <label for="frequency"><?php echo esc_html__('Number of daily articles', 'vuela-api-plugin'); ?></label>
            <input type="number" id="articles_per_day" name="articles_per_day" class="form-control input-text" min="1" style="width: 50px;">
        </div>

        <div class="form-group">
            <label>                
                <?php echo esc_html__('Include saturdays and', 'vuela-api-plugin').'<br>'.esc_html__('sundays', 'vuela-api-plugin'); ?>
            </label>            
            <input type="checkbox" id="include_weekends" name="include_weekends">            
        </div>

        

        <div class="form-group">
        <label>&nbsp;</label>
            <button type="button" name="program_schedule" id="program_schedule" class="btn-submit"><?php echo esc_html__('Schedule', 'vuela-api-plugin'); ?></button>
        </div>
    </div>
    </div>
            </div>
            
    
            <!-- Lista de contenidos -->
            <div class="content-list">
                <?php if ($contents): ?>
                    <table class="content-table" id="table_principal">
                        <thead>
                            <tr>
                                <th>
                                    <input type="checkbox" id="select-all" />
                                </th>
                                <th><?php echo esc_html__('Content ID', 'vuela-api-plugin'); ?></th>
                                <th><?php echo esc_html__('Title', 'vuela-api-plugin'); ?></th>
                                <th><?php echo esc_html__('Type', 'vuela-api-plugin'); ?></th>
                                <th><?php echo esc_html__('Status', 'vuela-api-plugin'); ?></th>
                                <th><?php echo esc_html__('Amount', 'vuela-api-plugin'); ?></th>
                                <th><?php echo esc_html__('Created At', 'vuela-api-plugin'); ?></th>
                                <th><?php echo esc_html__('Update At', 'vuela-api-plugin'); ?></th>
                                <th><?php echo esc_html__('Action', 'vuela-api-plugin'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($contents as $content): ?>
                                <tr>
                                    <td>
                                    <?php if(strtoupper($content['status'])=='COMPLETED'){ ?>
                                        <input type="checkbox" name="selected_contents[]" value="<?php echo esc_attr($content['id']); ?>" />
                                    <?php } ?>
                                    </td>
                                    <td><?php echo esc_html($content['id']); ?></td>
                                    <td><?php echo esc_html($content['name']); ?></td>
                                    <td><?php echo esc_html($content['type']); ?></td>
                                    <td><?php echo esc_html($content['status']); ?></td>
                                    <td><?php echo esc_html($content['amount']); ?></td>
                                    <td><?php echo date('d-m-Y H:i', strtotime($content['createdAt'])); ?></td>
                                    <td><?php echo date('d-m-Y H:i', strtotime($content['updatedAt'])); ?></td>
                                    <td>
                                    <?php if(strtoupper($content['status'])=='COMPLETED'){ ?>
                                        <div style="display: flex; align-items: center;gap: 10px;justify-content: center;">
                                    <?php if(strtoupper($content['importStatus'])=='COMPLETED'){ ?>
                                        <button type="button" name="import_item" class="btn-submit" onclick="generate_article_import(this,'<?php echo esc_html($content['id']); ?>')"><?php echo esc_html__('Reimport', 'vuela-api-plugin'); ?></button>
                                        <?php }else{ ?>
                                            <button type="button" name="import_item" class="btn-submit" onclick="generate_article_import(this,'<?php echo esc_html($content['id']); ?>')"><?php echo esc_html__('Import', 'vuela-api-plugin'); ?></button>
                                         <?php } ?>
                                         <!-- Botón para programar publicaciones con ícono de reloj -->
                                        <button type="button" name="schedule_posts_i" class="btn-schedule btn-submit" onclick="toggleScheduleForm(this)">
                                            <span class="dashicons dashicons-clock"></span>
                                        </button>
                                        </div>                                        
                                        <?php } ?>
                                    </td>                                    
                                </tr>
                                <tr class="schedule-options-individual" style="display: none;">
                                <td colspan="9">
                                    <div  style="display: flex; align-items: center;gap: 10px;justify-content: center;" >
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label for="start_date"><?php echo esc_html__('Publication date', 'vuela-api-plugin'); ?></label>
                                                <input type="date" name="start_date_i" class="form-control input-text">
                                            </div>
                                            <div class="form-group">
                                                <label for="schedule_time"><?php echo esc_html__('Publication time', 'vuela-api-plugin'); ?></label>
                                                <input type="time" name="schedule_time_i" class="form-control input-text">
                                            </div>

                                            <!-- Valores predefinidos ocultos -->
                                            <input type="hidden" name="frequency_i" value="1">
                                            <input type="hidden" name="articles_per_day_i" value="1">
                                            <input type="hidden" name="include_weekends_i" value="true">

                                            <div class="form-group">
                                            <label>&nbsp;</label>
                                                <button type="button" name="program_schedule_i" class="btn-submit" onclick="generate_article_import(this,'<?php echo esc_html($content['id']); ?>')" ><?php echo esc_html__('Schedule', 'vuela-api-plugin'); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p><?php echo esc_html__('No content found.', 'vuela-api-plugin'); ?></p>
                <?php endif; ?>
            </div>

            <!-- Paginación -->
            <div class="pagination">
                <?php
                $current_url = $_SERVER['REQUEST_URI'];
                $parsed_url = parse_url($current_url);
                parse_str(isset($parsed_url['query']) ? $parsed_url['query'] : '', $query_params);

                unset($query_params['paged']);

                $base_url = $parsed_url['path'] . '?' . http_build_query($query_params);
                for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="<?php echo esc_url($base_url . '&paged=' . $i); ?>" class="page-link <?php echo ($i === $page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        </div>
    </div>

</div>
<script>
function toggleScheduleForm(button) {
    // Buscar la fila principal
    var row = button.closest('tr');

    // Buscar la siguiente fila (que contiene el formulario)
    var scheduleRow = row.nextElementSibling;

    // Verificar si la fila ya está visible
    var isVisible = scheduleRow.style.display === "table-row";

    // Ocultar todas las filas de programación antes de abrir una nueva
    document.querySelectorAll('.schedule-options-individual').forEach(row => {
        row.style.display = "none";
    });

    // Si la fila no estaba visible, mostrarla; si ya lo estaba, dejarla oculta
    scheduleRow.style.display = isVisible ? "none" : "table-row";
}
</script>

