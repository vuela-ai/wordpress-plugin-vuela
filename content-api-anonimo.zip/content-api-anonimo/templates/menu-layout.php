<div class="plugin-container">
    <div class="sidebar">
        <div class="logo-vuela">
            <img src="https://vuela.ai/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Ficon.c86f5a54.png&w=48&q=75" alt="">
            <span class="font-bold text-3xl">Vuela</span>
        </div>
        <ul class="menu">
           <!-- <li><a href="?page=vuela-api-panel&section=articles" class="<?php echo (isset($_GET['section']) && $_GET['section'] == 'articles') ? 'active' : ''; ?>"><?php _e('Articles', 'vuela-api-plugin'); ?></a></li>-->
           <li><a href="?page=vuela-api-panel&section=my-content" class="<?php echo (isset($_GET['section']) && $_GET['section'] == 'my-content') ? 'active' : ''; ?>"><?php _e('My Content', 'vuela-api-plugin'); ?></a></li> 
           <li><a href="?page=vuela-api-panel&section=api-keys" class="<?php echo (isset($_GET['section']) && $_GET['section'] == 'api-keys') ? 'active' : ''; ?>"><?php _e('API Keys', 'vuela-api-plugin'); ?></a></li>            
        </ul>
    </div>
    <div class="vuela-main-content">
        <div class="vuela-content">
            <?php
            // Acceder a la instancia global de la clase Vuela_API_Plugin
            global $vuela_api_plugin;

            // Comprobar si la sección está definida
            if (isset($_GET['section'])) {
                switch ($_GET['section']) {
                    case 'articles':
                        //$vuela_api_plugin->render_articles_page(); // Renderizar artículos
                        break;
                    case 'api-keys':
                        $vuela_api_plugin->render_admin_page(); // Renderizar API Keys
                        break;
                    case 'my-content':
                        $vuela_api_plugin->render_my_content(); // Renderizar Mi Contenido
                        break;
                    default:
                     if (!vuela_is_token_valid()) { 
                        $vuela_api_plugin->render_admin_page();
                     }else{
                        $vuela_api_plugin->render_my_content();
                     }
                        
                        
                }
            } else {
                if (!vuela_is_token_valid()) { 
                    $vuela_api_plugin->render_admin_page();
                 }else{
                    $vuela_api_plugin->render_my_content();
                 }
               
            }
            ?>
        </div>
    </div>
</div>
