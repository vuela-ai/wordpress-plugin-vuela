<div class="wrap">
<?php if (!vuela_is_token_valid()) : ?>
        <div class="notice notice-warning">
            <p><?php _e('Add your API Key to use Vuela.', 'vuela-api-plugin'); ?></p>
        </div>
    <?php endif; ?>
    <div id="article-generation" class="playground-content">
        <h2><?php _e('Informative Article Generation', 'vuela-api-plugin'); ?></h2>

        <form id="article-generation-form" method="post" action="">
            <?php wp_nonce_field('vuela_api_article_generation', 'vuela_api_nonce'); ?>
            <div class="form-group">
                <label class="label cursor-pointer">
                    <span class="label-text mr-2 text-xs"><?php _e('Create in Bulk', 'vuela-api-plugin'); ?></span>
                    <input id="toggleSwitch" class="toggle-switch" type="checkbox">
                    <span class="slider"></span>
                </label>
            </div>


            <div class="form-group">
                <label for="select_type"><?php _e('Select Field', 'vuela-api-plugin'); ?></label>
                <select id="select_type" name="select_type">
                    <option value="title"><?php _e('Title', 'vuela-api-plugin'); ?></option>
                    <option value="keyword"><?php _e('Keyword', 'vuela-api-plugin'); ?></option>
                </select>
            </div>

            <div class="form-group article_title">
                <label for="article_title"><?php _e('Article Title', 'vuela-api-plugin'); ?></label>
                <input type="text" id="article_title" name="article_title" class="regular-text" placeholder="<?php _e('Title of the article', 'vuela-api-plugin'); ?>">
                <textarea id="article_bulk_input_title" name="article_bulk_input_title" rows="5" class="large-text" style="display:none;" placeholder="<?php _e('Title of the articles, one per line', 'vuela-api-plugin'); ?>"></textarea>
            </div>

            <div class="form-group article_keyword" style="display: none;">
                <label for="article_keyword"><?php _e('Keyword/Topic', 'vuela-api-plugin'); ?></label>
                <input type="text" id="article_keyword" name="article_keyword" class="regular-text" placeholder="<?php _e('Keyword', 'vuela-api-plugin'); ?>">
                <textarea id="article_bulk_input_keyword" name="article_bulk_input_keyword" rows="5" class="large-text" style="display:none;" placeholder="<?php _e('Keyword, one per line', 'vuela-api-plugin'); ?>"></textarea>
            </div>

            <div class="form-group">
                <label for="article_language"><?php _e('Language', 'vuela-api-plugin'); ?></label>
                <!--<input type="text" id="article_language" name="article_language" value="en" class="regular-text">-->
                <select id="article_language" name="article_language"><option value="EN" selected="">EN - English</option><option value="ES">ES - Español</option><option value="CA">CA - Català</option><option value="EU">EU - Euskara</option><option value="GL">GL - Galego</option><option value="FR">FR - Français</option><option value="DE">DE - Deutsch</option><option value="IT">IT - Italiano</option><option value="PT">PT - Português</option><option value="ZH">ZH - 中文</option><option value="JA">JA - 日本語</option><option value="KO">KO - 한국어</option><option value="RU">RU - Русский</option><option value="AR">AR - العربية</option><option value="HI">HI - हिंदी</option><option value="TR">TR - Türkçe</option><option value="NL">NL - Nederlands</option><option value="SV">SV - Svenska</option><option value="NO">NO - Norsk</option><option value="DA">DA - Dansk</option><option value="PL">PL - Polski</option><option value="CS">CS - Čeština</option><option value="EL">EL - Ελληνικά</option></select>
                <p class="description"><?php _e('Default is English ("en")', 'vuela-api-plugin'); ?></p>
            </div>

            <div class="form-group">
                <label for="article_country"><?php _e('Country', 'vuela-api-plugin'); ?></label>
                <!--<input type="text" id="article_country" name="article_country" value="US" class="regular-text">-->
                <select id="article_country" name="article_country" class="select select-bordered w-full text-sm"><option value="US" selected="">United States</option><option value="AR">Argentina</option><option value="AU">Australia</option><option value="AT">Austria</option><option value="AO">Angola</option><option value="BB">Barbados</option><option value="BY">Belarus</option><option value="BE">Belgium</option><option value="BJ">Benin</option><option value="BO">Bolivia</option><option value="BR">Brazil</option><option value="BF">Burkina Faso</option><option value="BI">Burundi</option><option value="CM">Cameroon</option><option value="CA">Canada</option><option value="CF">Central African Republic</option><option value="CL">Chile</option><option value="CN">China</option><option value="CO">Colombia</option><option value="CR">Costa Rica</option><option value="CU">Cuba</option><option value="CY">Cyprus</option><option value="CD">Democratic Republic of the Congo</option><option value="DK">Denmark</option><option value="DJ">Djibouti</option><option value="DO">Dominican Republic</option><option value="EC">Ecuador</option><option value="EG">Egypt</option><option value="SV">El Salvador</option><option value="GQ">Equatorial Guinea</option><option value="FR">France</option><option value="GA">Gabon</option><option value="GR">Greece</option><option value="GN">Guinea</option><option value="GW">Guinea-Bissau</option><option value="HT">Haiti</option><option value="HN">Honduras</option><option value="IN">India</option><option value="IQ">Iraq</option><option value="IE">Ireland</option><option value="IT">Italy</option><option value="JM">Jamaica</option><option value="JP">Japan</option><option value="JO">Jordan</option><option value="KZ">Kazakhstan</option><option value="KE">Kenya</option><option value="KW">Kuwait</option><option value="KG">Kyrgyzstan</option><option value="LB">Lebanon</option><option value="LI">Liechtenstein</option><option value="LU">Luxembourg</option><option value="MG">Madagascar</option><option value="MT">Malta</option><option value="MX">Mexico</option><option value="MA">Morocco</option><option value="MZ">Mozambique</option><option value="MM">Myanmar</option><option value="NI">Nicaragua</option><option value="NE">Niger</option><option value="NG">Nigeria</option><option value="KP">North Korea</option><option value="NO">Norway</option><option value="OM">Oman</option><option value="PK">Pakistan</option><option value="PA">Panama</option><option value="PY">Paraguay</option><option value="PE">Peru</option><option value="PL">Poland</option><option value="PT">Portugal</option><option value="QA">Qatar</option><option value="RO">Romania</option><option value="RU">Russia</option><option value="RW">Rwanda</option><option value="ST">São Tomé and Príncipe</option><option value="SA">Saudi Arabia</option><option value="SN">Senegal</option><option value="SG">Singapore</option><option value="SK">Slovakia</option><option value="SI">Slovenia</option><option value="ZA">South Africa</option><option value="KR">South Korea</option><option value="ES">Spain</option><option value="LK">Sri Lanka</option><option value="SE">Sweden</option><option value="CH">Switzerland</option><option value="SY">Syria</option><option value="TW">Taiwan</option><option value="TJ">Tajikistan</option><option value="TH">Thailand</option><option value="TL">Timor-Leste</option><option value="TN">Tunisia</option><option value="TR">Turkey</option><option value="UG">Uganda</option><option value="UA">Ukraine</option><option value="AE">United Arab Emirates</option><option value="GB">United Kingdom</option><option value="UY">Uruguay</option><option value="UZ">Uzbekistan</option><option value="VE">Venezuela</option><option value="YE">Yemen</option><option value="ZM">Zambia</option><option value="ZW">Zimbabwe</option></select>
                <p class="description"><?php _e('Default is United States ("US")', 'vuela-api-plugin'); ?></p>
            </div>

            <div class="form-group">
                <label for="article_focus"><?php _e('Additional Focus/Context', 'vuela-api-plugin'); ?></label>
                <textarea id="article_focus" name="article_focus" rows="3" class="large-text"></textarea>
            </div>

            <div class="form-group check-enlinea">
            <input type="checkbox" id="add_images" name="add_images" value="1">
            <label for="add_images"><?php _e('Add Images', 'vuela-api-plugin'); ?></label>
            </div>

            <div class="form-group images_focus" style="display: none;">
                <label for="images_focus"><?php _e('Images Focus', 'vuela-api-plugin'); ?></label>
                <textarea id="images_focus" name="images_focus" rows="5" class="large-text" style="display:none;" placeholder="<?php _e('Enter focus details for images', 'vuela-api-plugin'); ?>"></textarea>
            </div>
            <p></p>

            <p></p>
            <p class="description"><?php _e('Note: At least either the title or the keyword must be provided.', 'vuela-api-plugin'); ?></p>

            <p class="description"><?php _e('Generated content will be saved as a draft by default.', 'vuela-api-plugin'); ?></p>
            <div class="form-group check-enlinea">
                <input type="checkbox" id="publish_directly" name="publish_directly" value="1">
                <label for="publish_directly"><?php _e('Publish directly', 'vuela-api-plugin'); ?></label>
            </div>

            <input type="submit" name="generate_article" class="button button-primary" value="<?php _e('Generate Article', 'vuela-api-plugin'); ?>">
            <div id="vuela-api-response"></div>
        </form>
    </div>
</div>