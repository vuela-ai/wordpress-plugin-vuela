
<div class="wrap" style="display: flex; justify-content: center; align-items: center; height: 84vh;">
    <div class="playground-content" >
    <!--<h1><?php //echo esc_html__('Authentication', 'vuela-api-plugin'); ?></h1>-->
    
    <?php
    // Mostrar el formulario de login
   

    echo '<div class="login-container" style="display: flex; justify-content: center; align-items: center;">'; // Contenedor centrado
    echo '<form method="POST" action="" style="max-width: 400px; width: 100%;">'; // Estilo del formulario
    echo '<table class="form-table" style="width: 100%;">';
    echo '<tr><td><label for="username">' . __('Username:', 'vuela-api-plugin') . '</label></td>';
    echo '<td><input type="text" name="username" id="username" class="regular-text" required style="width: 100%;"></td></tr>';
    echo '<tr><td><label for="password">' . __('Password:', 'vuela-api-plugin') . '</label></td>';
    echo '<td><input type="password" name="password" id="password" class="regular-text" required style="width: 100%;"></td></tr>';
    echo '</table>';
    echo '<p class="submit" style="text-align: center;"><button type="submit" name="vuela_login" class="button button-primary">' . __('Login', 'vuela-api-plugin') . '</button></p>';
    echo '</form>';   

    echo '</div>';
    ?>
        
        
        
        
    </div>
</div>

    