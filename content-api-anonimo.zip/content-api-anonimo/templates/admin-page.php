
<div class="wrap">
<?php 
    if (isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true') {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php _e('Settings have been saved successfully!', 'vuela-api-plugin'); ?></p>
        </div>
        <?php
    }
    ?>
    <div class="playground-content">
    <h1><?php echo esc_html__('Connect Vuela with WordPress and boost your content', 'vuela-api-plugin'); ?></h1>
    <div style="background-color: #2b2c32; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
            <p>
                <?php _e('You can find your API Key <a href="https://vuela.ai/dashboard/api-keys" target="_blank">here</a>.', 'vuela-api-plugin'); ?>
            </p>
            <p>
                <?php _e('You can check or add more credits <a href="https://vuela.ai/dashboard/wallet" target="_blank">here</a>.', 'vuela-api-plugin'); ?>
            </p>
        </div>
        <div id="vuela-api-response"></div>
        
        <form id="vuela-api-form" method="post" action="options.php">
            <?php
                settings_fields('vuela_api_settings');
                do_settings_sections('vuela-api-settings');
                ?>
                <div id="div-api-form">
                <?php
                submit_button(__('Save Settings', 'vuela-api-plugin'));
                if (vuela_is_token_valid()){
                ?>
                <p>
                <button id="validate-token" class="button button-primary"><?php _e('Validate Token', 'vuela-api-plugin'); ?></button>
                </p>
                <?php
                }
                
            ?>
            </div>
        </form>
        
        
        
    </div>
</div>

    